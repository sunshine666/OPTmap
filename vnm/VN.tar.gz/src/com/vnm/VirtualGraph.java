package com.vnm;
import java.util.*;
/**
 * Created by vnm on 17-2-14.
 */
public class VirtualGraph {
    public int Node;
    public int Edge;
    public int VN2PN[];
    public List VE2PE[];
    public int VEindex;
    public double VEBandwidth[];

    public double NodeCapacity[];
    public double EdgeCapacity[][];
}
