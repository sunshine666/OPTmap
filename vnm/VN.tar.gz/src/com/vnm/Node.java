package com.vnm;

import java.util.Comparator;

/**
 * Created by vnm on 17-2-16.
 * Used in HAR
 */
public class Node {
    public int Capacity;
    public int Id;

    public Node(int capcity, int id) {
        Capacity = capcity;
        Id = id;
    }
}
