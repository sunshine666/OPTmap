package com.vnm;


import java.io.File;
import java.io.IOException;
import java.lang.reflect.Field;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
    	int PGpara = Integer.parseInt(args[0]);
	System.out.println("sdf  "+PGpara);
    }
}
