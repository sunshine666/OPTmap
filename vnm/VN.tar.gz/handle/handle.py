#!/usr/bin/python
# -*- coding: UTF-8 -*-

import sys
import os


os.system("javac *.java")
os.system("java BDcost")
os.system("java Executetime")
os.system("java revenue")
os.system("java VNmappedratio")
os.system("java Vlinkration")
